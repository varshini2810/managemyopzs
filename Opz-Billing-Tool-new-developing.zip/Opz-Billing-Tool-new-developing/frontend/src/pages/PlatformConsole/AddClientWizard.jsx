import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Building, User, Lock, CheckCircle, ChevronRight, Check, AlertTriangle, ArrowLeft } from 'lucide-react';
import api from '../../services/api';

const SUITES = [
  {
    id: 'billing', name: 'Chargebee Billing',
    modules: [
      { id: 'home', name: 'Home' },
      { id: 'customers', name: 'Customers' },
      { id: 'subscription', name: 'Subscription' },
      { id: 'invoices', name: 'Invoices & Credit Notes' },
      { id: 'catalog', name: 'Product Catalog' },
      { id: 'logs', name: 'Logs' },
      { id: 'revenue-story', name: 'Revenue Story' },
      { id: 'classic-reports', name: 'Classic Reports' },
      { id: 'apps', name: 'Apps' },
      { id: 'settings', name: 'Settings' }
    ]
  },
  {
    id: 'cpq', name: 'Chargebee CPQ',
    modules: [
      { id: 'quotes', name: 'Quotes' },
      { id: 'settings', name: 'Settings' }
    ]
  },
  {
    id: 'receivables', name: 'Chargebee Receivables',
    modules: [
      { id: 'dashboard', name: 'AR Dashboard' },
      { id: 'collections', name: 'Collections Queue' },
      { id: 'reconciliation', name: 'Payment Reconciliation' },
      { id: 'disputes', name: 'Dispute Management' },
      { id: 'write-off', name: 'Bad Debt Write-off' }
    ]
  },
  {
    id: 'retention', name: 'Chargebee Retention',
    modules: [
      { id: 'cancel-flows', name: 'Cancel Flows' },
      { id: 'churn-reasons', name: 'Churn Reasons' },
      { id: 'winback', name: 'Winback Campaigns' },
      { id: 'at-risk', name: 'At-Risk Signals' },
      { id: 'activity-log', name: 'Activity Log' }
    ]
  },
  {
    id: 'revrec', name: 'Chargebee RevRec',
    modules: [
      { id: 'schedules', name: 'Revenue Schedules' },
      { id: 'waterfall', name: 'Revenue Waterfall' },
      { id: 'obligations', name: 'Performance Obligations' },
      { id: 'modifications', name: 'Contract Modifications' },
      { id: 'journal-entries', name: 'Journal Entries' },
      { id: 'audit-trail', name: 'Audit Trail' }
    ]
  },
  {
    id: 'payments', name: 'Chargebee Payments',
    modules: [
      { id: 'transactions', name: 'Transactions' },
      { id: 'sources', name: 'Payment Sources' },
      { id: 'refunds', name: 'Refunds' },
      { id: 'gateway-health', name: 'Gateway Health' },
      { id: 'payouts', name: 'Payout Reconciliation' }
    ]
  },
  {
    id: 'growth', name: 'Chargebee Growth',
    modules: [
      { id: 'pricing-experiments', name: 'Pricing Experiments' },
      { id: 'checkout-optimization', name: 'Checkout Optimization' },
      { id: 'upsell-rules', name: 'Upsell/Cross-sell Rules' },
      { id: 'referrals', name: 'Referral Programs' }
    ]
  }
];

export default function AddClientWizard() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [subdomainStatus, setSubdomainStatus] = useState(null); // 'checking', 'available', 'taken'
  
  const [formData, setFormData] = useState({
    companyName: '',
    subdomain: '',
    businessEmail: '',
    businessPhone: '',
    gstNumber: '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    state: '',
    pincode: '',
    country: '',
    industry: 'SaaS',
    status: 'Active',
    adminFullName: '',
    adminEmail: '',
    confirmEmail: false,
    grantedModules: [] // array of strings "suite:module"
  });

  const [presets, setPresets] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [createdPassword, setCreatedPassword] = useState(null);

  useEffect(() => {
    api.get('/admin/access-presets').then(res => setPresets(res.data.data)).catch(console.error);
  }, []);

  useEffect(() => {
    if (formData.companyName && !formData.subdomain && step === 1) {
      setFormData(prev => ({
        ...prev,
        subdomain: formData.companyName.toLowerCase().replace(/[^a-z0-9]/g, '')
      }));
    }
  }, [formData.companyName, step, formData.subdomain]);

  useEffect(() => {
    if (formData.subdomain.length > 2) {
      setSubdomainStatus('checking');
      const timer = setTimeout(() => {
        api.get(`/admin/clients/check-subdomain?value=${formData.subdomain}`)
          .then(res => {
            setSubdomainStatus(res.data.data ? 'available' : 'taken');
          })
          .catch(() => setSubdomainStatus('error'));
      }, 500);
      return () => clearTimeout(timer);
    } else {
      setSubdomainStatus(null);
    }
  }, [formData.subdomain]);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleModuleToggle = (suiteId, moduleId, checked) => {
    const key = `${suiteId}:${moduleId}`;
    setFormData(prev => ({
      ...prev,
      grantedModules: checked 
        ? [...prev.grantedModules, key] 
        : prev.grantedModules.filter(m => m !== key)
    }));
  };

  const handleSuiteToggle = (suiteId, checked) => {
    const suite = SUITES.find(s => s.id === suiteId);
    const keys = suite.modules.map(m => `${suiteId}:${m.id}`);
    
    setFormData(prev => {
      let newModules = [...prev.grantedModules];
      if (checked) {
        keys.forEach(k => {
          if (!newModules.includes(k)) newModules.push(k);
        });
      } else {
        newModules = newModules.filter(m => !keys.includes(m));
      }
      return { ...prev, grantedModules: newModules };
    });
  };

  const applyPreset = (presetId) => {
    if (!presetId) return;
    const preset = presets.find(p => p.id === presetId);
    if (preset) {
      setFormData(prev => ({ ...prev, grantedModules: preset.moduleKeys }));
    }
  };

  const isStepValid = () => {
    if (step === 1) {
      return formData.companyName && formData.subdomain && subdomainStatus === 'available' && 
             formData.businessEmail && formData.businessPhone && formData.addressLine1 && 
             formData.city && formData.state && formData.pincode && formData.country;
    }
    if (step === 2) {
      return formData.adminFullName && formData.adminEmail && formData.confirmEmail;
    }
    if (step === 3) {
      return formData.grantedModules.length > 0;
    }
    return true;
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    try {
      const res = await api.post('/admin/clients', formData);
      setCreatedPassword(res.data.data.temporaryPassword);
      setStep(5);
    } catch (error) {
      console.error(error);
      alert('Failed to create client. ' + (error.response?.data?.message || ''));
    } finally {
      setIsSubmitting(false);
    }
  };

  const steps = [
    { num: 1, label: 'Business Details', icon: Building },
    { num: 2, label: 'Admin Account', icon: User },
    { num: 3, label: 'Module Access', icon: Lock },
    { num: 4, label: 'Review & Create', icon: CheckCircle }
  ];

  if (step === 5) {
    return (
      <div className="max-w-3xl mx-auto mt-16 p-8 bg-white border border-slate-200 rounded-xl shadow-sm text-center">
        <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <Check size={32} />
        </div>
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Client Created Successfully!</h2>
        <p className="text-slate-600 mb-8">
          <strong>{formData.companyName}</strong> has been onboarded to the platform.
        </p>

        <div className="bg-slate-50 border border-slate-200 rounded-lg p-6 mb-8 text-left">
          <div className="grid grid-cols-2 gap-y-4 text-sm">
            <div className="text-slate-500">Subdomain URL</div>
            <div className="font-medium text-primary-600">https://{formData.subdomain}.opz.com</div>
            
            <div className="text-slate-500">Admin Login Email</div>
            <div className="font-medium text-slate-900">{formData.adminEmail}</div>
            
            <div className="text-slate-500">Temporary Password</div>
            <div className="font-mono text-slate-900 bg-white border border-slate-200 px-2 py-1 rounded inline-block">
              {createdPassword}
            </div>
          </div>
        </div>

        <p className="text-sm text-slate-500 mb-8">
          The credentials have been securely emailed to the admin. The temporary password will expire in 24 hours.
        </p>

        <div className="flex gap-4 justify-center">
          <button 
            onClick={() => navigate('/platform-console/clients')}
            className="px-6 py-2 bg-slate-100 text-slate-700 font-medium rounded-lg hover:bg-slate-200"
          >
            Back to Client List
          </button>
          <button 
            onClick={() => {
              navigator.clipboard.writeText(`Login URL: https://${formData.subdomain}.opz.com\nEmail: ${formData.adminEmail}\nPassword: ${createdPassword}`);
              alert('Copied to clipboard');
            }}
            className="px-6 py-2 bg-primary-600 text-white font-medium rounded-lg hover:bg-primary-700"
          >
            Copy Credentials
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-8 max-w-6xl mx-auto h-[calc(100vh-64px)] flex flex-col">
      <div className="flex items-center gap-4 mb-8">
        <button onClick={() => navigate('/platform-console/clients')} className="p-2 hover:bg-slate-100 rounded-full text-slate-500 transition-colors">
          <ArrowLeft size={20} />
        </button>
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Add New Client</h1>
          <p className="text-slate-500 text-sm mt-1">Onboard a new tenant and configure their platform access.</p>
        </div>
      </div>

      <div className="flex gap-8 flex-1 min-h-0">
        {/* Left Sidebar Steps */}
        <div className="w-64 shrink-0 border-r border-slate-200 pr-8">
          <div className="space-y-6 relative">
            <div className="absolute left-4 top-4 bottom-4 w-px bg-slate-200 -z-10" />
            {steps.map((s, i) => {
              const isActive = step === s.num;
              const isPast = step > s.num;
              const Icon = s.icon;
              return (
                <div key={s.num} className="flex items-start gap-4">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-colors ${
                    isActive ? 'bg-primary-600 text-white ring-4 ring-primary-50' :
                    isPast ? 'bg-green-500 text-white' :
                    'bg-slate-100 text-slate-400 border border-slate-200'
                  }`}>
                    {isPast ? <Check size={16} /> : <Icon size={16} />}
                  </div>
                  <div className="pt-1.5">
                    <div className={`text-sm font-medium ${isActive ? 'text-slate-900' : isPast ? 'text-slate-700' : 'text-slate-400'}`}>
                      {s.label}
                    </div>
                    {isActive && <div className="text-xs text-primary-600 mt-0.5">In Progress</div>}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Content Area */}
        <div className="flex-1 bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col overflow-hidden">
          <div className="p-8 flex-1 overflow-y-auto">
            
            {/* STEP 1: BUSINESS DETAILS */}
            {step === 1 && (
              <div className="space-y-6 max-w-2xl">
                <h2 className="text-lg font-bold text-slate-900 mb-4">Business Details</h2>
                
                <div className="grid grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Company Name *</label>
                    <input type="text" name="companyName" value={formData.companyName} onChange={handleChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500" placeholder="Acme Corp" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Subdomain *</label>
                    <div className="relative">
                      <input type="text" name="subdomain" value={formData.subdomain} onChange={handleChange} className="w-full pl-3 pr-24 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500" placeholder="acme" />
                      <div className="absolute right-3 top-1/2 -translate-y-1/2 text-sm text-slate-400 pointer-events-none">.opz.com</div>
                    </div>
                    {subdomainStatus === 'checking' && <div className="text-xs text-blue-500 mt-1">Checking availability...</div>}
                    {subdomainStatus === 'available' && <div className="text-xs text-green-600 mt-1">Subdomain available</div>}
                    {subdomainStatus === 'taken' && <div className="text-xs text-red-500 mt-1">Subdomain is already taken</div>}
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Business Email *</label>
                    <input type="email" name="businessEmail" value={formData.businessEmail} onChange={handleChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Phone Number *</label>
                    <input type="tel" name="businessPhone" value={formData.businessPhone} onChange={handleChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500" />
                  </div>

                  <div className="col-span-2">
                    <label className="block text-sm font-medium text-slate-700 mb-1">Address Line 1 *</label>
                    <input type="text" name="addressLine1" value={formData.addressLine1} onChange={handleChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500" />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">City *</label>
                    <input type="text" name="city" value={formData.city} onChange={handleChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">State / Province *</label>
                    <input type="text" name="state" value={formData.state} onChange={handleChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500" />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">ZIP / Postal Code *</label>
                    <input type="text" name="pincode" value={formData.pincode} onChange={handleChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Country *</label>
                    <select name="country" value={formData.country} onChange={handleChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500">
                      <option value="">Select Country</option>
                      <option value="US">United States</option>
                      <option value="CA">Canada</option>
                      <option value="GB">United Kingdom</option>
                      <option value="IN">India</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Industry</label>
                    <select name="industry" value={formData.industry} onChange={handleChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500">
                      <option value="SaaS">SaaS</option>
                      <option value="E-commerce">E-commerce</option>
                      <option value="EdTech">EdTech</option>
                      <option value="HealthTech">HealthTech</option>
                      <option value="Media">Media/OTT</option>
                      <option value="Other">Other</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Initial Status</label>
                    <select name="status" value={formData.status} onChange={handleChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500">
                      <option value="Active">Active (Production)</option>
                      <option value="Trial">Trial (Evaluation)</option>
                    </select>
                  </div>
                </div>
              </div>
            )}

            {/* STEP 2: ADMIN ACCOUNT */}
            {step === 2 && (
              <div className="space-y-6 max-w-xl">
                <h2 className="text-lg font-bold text-slate-900 mb-4">Tenant Admin Account</h2>
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg flex items-start gap-3 mb-6">
                  <User size={20} className="text-blue-600 mt-0.5" />
                  <div className="text-sm text-blue-800">
                    This user will act as the master administrator for the tenant. They will receive the initial login credentials and can subsequently invite other team members.
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Admin Full Name *</label>
                    <input type="text" name="adminFullName" value={formData.adminFullName} onChange={handleChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500" placeholder="Jane Doe" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-slate-700 mb-1">Admin Login Email *</label>
                    <input type="email" name="adminEmail" value={formData.adminEmail} onChange={handleChange} className="w-full px-3 py-2 border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500" placeholder="jane@acme.com" />
                  </div>
                  
                  <div className="mt-6 pt-6 border-t border-slate-200">
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input type="checkbox" name="confirmEmail" checked={formData.confirmEmail} onChange={handleChange} className="mt-1 border-slate-300 rounded text-primary-600 focus:ring-primary-500" />
                      <span className="text-sm text-slate-700">
                        I confirm that the temporary password and login instructions should be sent to <strong>{formData.adminEmail || '(Email)'}</strong>.
                      </span>
                    </label>
                  </div>
                </div>
              </div>
            )}

            {/* STEP 3: MODULE ACCESS */}
            {step === 3 && (
              <div className="max-w-4xl">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h2 className="text-lg font-bold text-slate-900">Module Access Assignment</h2>
                    <p className="text-sm text-slate-500 mt-1">Select the suites and modules this tenant is allowed to use.</p>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="px-3 py-1.5 bg-slate-100 rounded-lg text-sm font-medium text-slate-700 border border-slate-200">
                      {formData.grantedModules.length} of 37 modules selected
                    </div>
                    
                    <select 
                      onChange={(e) => applyPreset(e.target.value)}
                      className="px-3 py-1.5 bg-white border border-slate-300 rounded-lg text-sm focus:ring-2 focus:ring-primary-500"
                    >
                      <option value="">Use a Preset...</option>
                      {presets.map(p => (
                        <option key={p.id} value={p.id}>{p.presetName}</option>
                      ))}
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-x-8 gap-y-6">
                  {SUITES.map(suite => {
                    const suiteKeys = suite.modules.map(m => `${suite.id}:${m.id}`);
                    const grantedCount = suiteKeys.filter(k => formData.grantedModules.includes(k)).length;
                    const isAllGranted = grantedCount === suite.modules.length;
                    
                    return (
                      <div key={suite.id} className="border border-slate-200 rounded-xl overflow-hidden bg-white">
                        <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
                          <label className="flex items-center gap-3 cursor-pointer">
                            <input 
                              type="checkbox" 
                              checked={isAllGranted}
                              onChange={(e) => handleSuiteToggle(suite.id, e.target.checked)}
                              className="w-4 h-4 text-primary-600 rounded border-slate-300 focus:ring-primary-500"
                            />
                            <span className="font-semibold text-slate-900">{suite.name}</span>
                          </label>
                          <span className="text-xs font-medium text-slate-500 bg-white px-2 py-1 rounded border border-slate-200">
                            {grantedCount}/{suite.modules.length}
                          </span>
                        </div>
                        <div className="p-4 grid grid-cols-2 gap-y-3 gap-x-4">
                          {suite.modules.map(mod => {
                            const key = `${suite.id}:${mod.id}`;
                            const isChecked = formData.grantedModules.includes(key);
                            return (
                              <label key={mod.id} className="flex items-center gap-2.5 cursor-pointer group">
                                <input 
                                  type="checkbox"
                                  checked={isChecked}
                                  onChange={(e) => handleModuleToggle(suite.id, mod.id, e.target.checked)}
                                  className="text-primary-600 rounded border-slate-300 focus:ring-primary-500"
                                />
                                <span className={`text-sm ${isChecked ? 'text-slate-900 font-medium' : 'text-slate-600 group-hover:text-slate-900'}`}>
                                  {mod.name}
                                </span>
                              </label>
                            );
                          })}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* STEP 4: REVIEW */}
            {step === 4 && (
              <div className="max-w-4xl space-y-8">
                <h2 className="text-lg font-bold text-slate-900 mb-4">Review & Create</h2>

                <div className="grid grid-cols-2 gap-8">
                  <div className="space-y-6">
                    <div className="bg-slate-50 border border-slate-200 p-5 rounded-xl">
                      <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-4">Business Details</h3>
                      <dl className="grid grid-cols-2 gap-y-3 text-sm">
                        <dt className="text-slate-500">Company</dt><dd className="font-medium text-slate-900">{formData.companyName}</dd>
                        <dt className="text-slate-500">Subdomain</dt><dd className="font-medium text-slate-900">{formData.subdomain}.opz.com</dd>
                        <dt className="text-slate-500">Email</dt><dd className="font-medium text-slate-900">{formData.businessEmail}</dd>
                        <dt className="text-slate-500">Status</dt><dd className="font-medium text-slate-900">{formData.status}</dd>
                        <dt className="text-slate-500">Country</dt><dd className="font-medium text-slate-900">{formData.country}</dd>
                      </dl>
                    </div>

                    <div className="bg-slate-50 border border-slate-200 p-5 rounded-xl">
                      <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider mb-4">Admin Account</h3>
                      <dl className="grid grid-cols-2 gap-y-3 text-sm">
                        <dt className="text-slate-500">Name</dt><dd className="font-medium text-slate-900">{formData.adminFullName}</dd>
                        <dt className="text-slate-500">Email</dt><dd className="font-medium text-slate-900">{formData.adminEmail}</dd>
                      </dl>
                    </div>
                  </div>

                  <div className="bg-slate-50 border border-slate-200 p-5 rounded-xl flex flex-col">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-sm font-bold text-slate-500 uppercase tracking-wider">Granted Access</h3>
                      <span className="text-xs font-bold bg-primary-100 text-primary-700 px-2 py-0.5 rounded-full">
                        {formData.grantedModules.length} Modules
                      </span>
                    </div>
                    
                    <div className="flex-1 overflow-y-auto pr-2 space-y-4 max-h-[400px]">
                      {SUITES.map(suite => {
                        const grantedInSuite = suite.modules.filter(m => formData.grantedModules.includes(`${suite.id}:${m.id}`));
                        if (grantedInSuite.length === 0) return null;
                        
                        return (
                          <div key={suite.id}>
                            <div className="text-sm font-semibold text-slate-900 mb-1">{suite.name}</div>
                            <div className="flex flex-wrap gap-1.5">
                              {grantedInSuite.map(m => (
                                <span key={m.id} className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-white border border-slate-200 text-slate-600">
                                  {m.name}
                                </span>
                              ))}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            )}
            
          </div>

          {/* Footer Controls */}
          <div className="p-4 border-t border-slate-200 bg-slate-50 flex items-center justify-between">
            <button 
              onClick={() => setStep(step - 1)}
              disabled={step === 1 || isSubmitting}
              className="px-6 py-2.5 text-sm font-medium text-slate-600 hover:text-slate-900 disabled:opacity-30"
            >
              Back
            </button>
            
            {step < 4 ? (
              <button 
                onClick={() => setStep(step + 1)}
                disabled={!isStepValid()}
                className="flex items-center gap-2 px-6 py-2.5 bg-primary-600 text-white text-sm font-medium rounded-lg hover:bg-primary-700 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                Continue <ChevronRight size={16} />
              </button>
            ) : (
              <button 
                onClick={handleSubmit}
                disabled={isSubmitting}
                className="flex items-center gap-2 px-8 py-2.5 bg-green-600 text-white text-sm font-medium rounded-lg hover:bg-green-700 disabled:opacity-50"
              >
                {isSubmitting ? 'Creating...' : 'Create Client'} <Check size={16} />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
