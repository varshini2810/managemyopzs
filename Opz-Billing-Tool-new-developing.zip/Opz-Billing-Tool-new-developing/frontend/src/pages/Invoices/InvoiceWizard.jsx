import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Save, FileText, CheckCircle, Check, Plus, Trash2, Printer, Search, Download } from 'lucide-react';
import api from '../../services/api';
import toast from 'react-hot-toast';
import { z } from 'zod';

const customerSchema = z.object({
  name: z.string().min(1, 'Name is required'),
  email: z.string().email('Valid email is required'),
  companyName: z.string().min(1, 'Company Name is required'),
  gstNumber: z.string().min(1, 'GST/VAT Number is required'),
  phone: z.string().min(1, 'Phone is required')
});

const lineItemSchema = z.object({
  name: z.string().min(1, 'Description is required'),
  price: z.number().min(0, 'Price must be >= 0'),
  qty: z.number().min(1, 'Quantity must be >= 1')
});

export default function InvoiceWizard() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState({});

  // Step 1: Customer & Tax
  const [customer, setCustomer] = useState({
    name: '', companyName: '', gstNumber: '', phone: '',
    addressLine1: '', addressLine2: '', city: '', state: '', pincode: '', taxPercentage: '18'
  });
  const [customTax, setCustomTax] = useState('');

  // Step 2: Line Items
  const [lineItemTab, setLineItemTab] = useState('products');
  const [products, setProducts] = useState([{ name: '', hsnCode: '', price: 0, qty: 1, gst: '18', customGst: '' }]);
  const [services, setServices] = useState([{ name: '', sacCode: '', price: 0, qty: 1, gst: '18', customGst: '' }]);

  // Step 3: Review
  const [dueDate, setDueDate] = useState('');

  // Autocomplete cache & states
  const [searchCache, setSearchCache] = useState({});
  const [suggestions, setSuggestions] = useState([]);
  const [activeInput, setActiveInput] = useState(null); // { type: 'product', index: 0 }

  useEffect(() => {
    // Debounce effect for HSN/SAC search
    if (activeInput) {
      const query = activeInput.type === 'product' ? products[activeInput.index].name : services[activeInput.index].name;
      if (query.length > 2) {
        const timer = setTimeout(() => fetchTaxLookup(query, activeInput.type), 300);
        return () => clearTimeout(timer);
      } else {
        setSuggestions([]);
      }
    }
  }, [activeInput, products, services]);

  const fetchTaxLookup = async (query, type) => {
    if (searchCache[query]) {
      setSuggestions(searchCache[query]);
      return;
    }
    try {
      const endpoint = type === 'product' ? '/tax-lookup/hsn' : '/tax-lookup/sac';
      const res = await api.get(`${endpoint}?query=${encodeURIComponent(query)}`);
      const cacheData = [res.data.data]; // Mock returns a single cache object
      setSearchCache(prev => ({ ...prev, [query]: cacheData }));
      setSuggestions(cacheData);
    } catch (e) {
      console.error(e);
      setSuggestions([]);
    }
  };

  const handleSuggestionSelect = (suggestion) => {
    if (activeInput.type === 'product') {
      const newProds = [...products];
      newProds[activeInput.index].hsnCode = suggestion.hsnOrSacCode;
      if (suggestion.gstRate) newProds[activeInput.index].gst = suggestion.gstRate.toString();
      setProducts(newProds);
    } else {
      const newSrvs = [...services];
      newSrvs[activeInput.index].sacCode = suggestion.hsnOrSacCode;
      if (suggestion.gstRate) newSrvs[activeInput.index].gst = suggestion.gstRate.toString();
      setServices(newSrvs);
    }
    setSuggestions([]);
    setSuggestions([]);
    setActiveInput(null);
  };

  const handleNextStep = () => {
    setErrors({});
    if (step === 1) {
      const res = customerSchema.safeParse(customer);
      if (!res.success) {
        const newErrs = {};
        res.error.issues.forEach(i => newErrs[i.path[0]] = i.message);
        setErrors(newErrs);
        toast.error('Please fix errors in Customer Details');
        return;
      }
    } else if (step === 2) {
      const allCombined = [...products.filter(i => i.name), ...services.filter(i => i.name)];
      if (allCombined.length === 0) {
        toast.error('Please add at least one product or service line item');
        return;
      }
      const allValid = allCombined.every(i => lineItemSchema.safeParse(i).success);
      if (!allValid) {
        toast.error('Please fix line items: every item needs a name, price ≥ 0, qty ≥ 1');
        return;
      }
    }
    setStep(step + 1);
  };

  const handleGenerate = async () => {
    if (!dueDate) {
      toast.error('Please select a Due Date before generating');
      return;
    }
    try {
      setLoading(true);
      
      const allItems = [
        ...products.filter(p => p.name).map(p => ({
          description: p.name,
          quantity: p.qty,
          unitAmount: p.price,
          itemType: 'PRODUCT',
          hsnSacCode: p.hsnCode,
          itemGstPercentage: parseFloat(p.gst === 'Others' ? p.customGst : p.gst) || 0
        })),
        ...services.filter(s => s.name).map(s => ({
          description: s.name,
          quantity: s.qty,
          unitAmount: s.price,
          itemType: 'SERVICE',
          hsnSacCode: s.sacCode,
          itemGstPercentage: parseFloat(s.gst === 'Others' ? s.customGst : s.gst) || 0
        }))
      ];

      if (allItems.length === 0) {
        toast.error('Please add at least one product or service line item');
        setLoading(false);
        return;
      }

      // Create customer first (required by foreign key)
      const customerPayload = {
        firstName: customer.name.split(' ')[0] || 'Unknown',
        lastName: customer.name.split(' ').slice(1).join(' ') || '',
        companyName: customer.companyName,
        email: customer.email,
        phone: customer.phone,
        billingLine1: customer.addressLine1,
        billingLine2: customer.addressLine2,
        billingCity: customer.city,
        billingState: customer.state,
        billingZip: customer.pincode,
        vatNumber: customer.gstNumber
      };
      
      const customerRes = await api.post('/customers', customerPayload);
      // Handle both res.data.data.id and res.data.id shapes
      const generatedCustomerId = (customerRes.data.data || customerRes.data).id;

      const totals = calculateTotal();
      const payload = {
        customerId: generatedCustomerId,
        status: 'DRAFT',
        invoiceDate: new Date().toISOString().slice(0, 19),
        dueDate: new Date(dueDate).toISOString().slice(0, 19),
        currency: 'USD',
        subtotal: totals.sub,
        taxTotal: totals.tax,
        total: totals.grand,
        lineItems: allItems
      };

      const res = await api.post('/invoices', payload);
      // Handle both res.data.data.id and res.data.id shapes
      const invoiceData = res.data.data || res.data;
      toast.success(`Invoice ${invoiceData.id} Generated Successfully!`);

      // Auto-download PDF immediately after generation
      try {
        const pdfResponse = await api.get(`/invoices/${invoiceData.id}/pdf`, { responseType: 'blob' });
        const pdfBlob = new Blob([pdfResponse.data], { type: 'application/pdf' });
        const pdfUrl = URL.createObjectURL(pdfBlob);
        const a = document.createElement('a');
        a.href = pdfUrl;
        a.download = `Invoice_${invoiceData.id}.pdf`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(pdfUrl);
        toast.success('PDF downloaded!', { duration: 2000 });
      } catch (pdfErr) {
        console.warn('PDF auto-download failed (non-fatal):', pdfErr);
      }

      navigate('/invoices');
    } catch (e) {
      console.error('Invoice generation error:', e?.response?.data || e.message);
      const errMsg = e?.response?.data?.message || e?.message || 'Failed to generate invoice';
      toast.error(errMsg);
    } finally {
      setLoading(false);
    }
  };

  const calculateTotal = () => {
    let sub = 0;
    let tax = 0;
    const processItems = (items) => {
      items.forEach(item => {
        if (!item.name) return;
        const lineTotal = item.price * item.qty;
        sub += lineTotal;
        const rate = parseFloat(item.gst === 'Others' ? item.customGst : item.gst) || 0;
        tax += (lineTotal * rate) / 100;
      });
    };
    processItems(products);
    processItems(services);
    return { sub, tax, grand: sub + tax };
  };

  const totals = calculateTotal();

  return (
    <div className="flex flex-col h-full bg-body">
      <div className="module-header border-b border-gray-200">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/invoices')} className="text-muted hover:text-ink transition-colors">
            <ArrowLeft size={18} />
          </button>
          <div>
            <h1 className="page-title">Create Invoice</h1>
            <p className="page-subtitle">Auto-generated Invoice Number: <span className="font-mono text-ink bg-gray-100 px-2 py-0.5 rounded">INV-[TENANT]-YYYY-XXXX</span></p>
          </div>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Left Rail (Steps) */}
        <div className="w-64 bg-surface border-r border-gray-200 p-6 flex flex-col gap-6">
          {[
            { num: 1, title: 'Customer & Tax Details' },
            { num: 2, title: 'Line Items' },
            { num: 3, title: 'Review & Generate' }
          ].map(s => (
            <div key={s.num} className={`flex items-center gap-3 ${step === s.num ? 'text-accent' : step > s.num ? 'text-green-600' : 'text-muted'}`}>
              <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-medium border ${step === s.num ? 'border-accent bg-accent/10' : step > s.num ? 'border-green-600 bg-green-50' : 'border-gray-300'}`}>
                {step > s.num ? <Check size={12} /> : s.num}
              </div>
              <span className="text-sm font-medium">{s.title}</span>
            </div>
          ))}
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-8 bg-body">
          <div className="max-w-4xl mx-auto bg-surface rounded-lg border border-gray-200 p-6 shadow-sm">
            
            {/* STEP 1 */}
            {step === 1 && (
              <div className="space-y-6">
                <h2 className="text-lg font-semibold text-ink mb-4">Customer Details</h2>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="label">Name *</label>
                    <input className={`input w-full ${errors.name ? 'input-error' : ''}`} value={customer.name || ''} onChange={e => setCustomer({...customer, name: e.target.value})} />
                    {errors.name && <span className="error-msg">{errors.name}</span>}
                  </div>
                  <div>
                    <label className="label">Email Address *</label>
                    <input type="email" className={`input w-full ${errors.email ? 'input-error' : ''}`} value={customer.email || ''} onChange={e => setCustomer({...customer, email: e.target.value})} />
                    {errors.email && <span className="error-msg">{errors.email}</span>}
                  </div>
                  <div>
                    <label className="label">Company Name *</label>
                    <input className={`input w-full ${errors.companyName ? 'input-error' : ''}`} value={customer.companyName || ''} onChange={e => setCustomer({...customer, companyName: e.target.value})} />
                    {errors.companyName && <span className="error-msg">{errors.companyName}</span>}
                  </div>
                  <div>
                    <label className="label">GST / VAT Number *</label>
                    <input className={`input w-full ${errors.gstNumber ? 'input-error' : ''}`} value={customer.gstNumber || ''} onChange={e => setCustomer({...customer, gstNumber: e.target.value})} />
                    {errors.gstNumber && <span className="error-msg">{errors.gstNumber}</span>}
                  </div>
                  <div>
                    <label className="label">Phone Number *</label>
                    <input className={`input w-full ${errors.phone ? 'input-error' : ''}`} value={customer.phone || ''} onChange={e => setCustomer({...customer, phone: e.target.value})} />
                    {errors.phone && <span className="error-msg">{errors.phone}</span>}
                  </div>
                </div>

                <h2 className="text-lg font-semibold border-b border-gray-100 pb-2 pt-4">Address</h2>
                <div className="grid grid-cols-2 gap-4">
                  <input className="input w-full col-span-2" placeholder="Line 1" value={customer.addressLine1} onChange={e => setCustomer({...customer, addressLine1: e.target.value})} />
                  <input className="input w-full col-span-2" placeholder="Line 2" value={customer.addressLine2} onChange={e => setCustomer({...customer, addressLine2: e.target.value})} />
                  <input className="input w-full" placeholder="City" value={customer.city} onChange={e => setCustomer({...customer, city: e.target.value})} />
                  <input className="input w-full" placeholder="State" value={customer.state} onChange={e => setCustomer({...customer, state: e.target.value})} />
                  <input className="input w-full" placeholder="Pincode" value={customer.pincode} onChange={e => setCustomer({...customer, pincode: e.target.value})} />
                </div>

                <h2 className="text-lg font-semibold border-b border-gray-100 pb-2 pt-4">Default Tax</h2>
                <div className="flex gap-4">
                  <select className="input w-48" value={customer.taxPercentage} onChange={e => setCustomer({...customer, taxPercentage: e.target.value})}>
                    <option value="5">5%</option>
                    <option value="12">12%</option>
                    <option value="18">18%</option>
                    <option value="Others">Others</option>
                  </select>
                  {customer.taxPercentage === 'Others' && (
                    <input className="input w-32" type="number" placeholder="Custom %" value={customTax} onChange={e => setCustomTax(e.target.value)} />
                  )}
                </div>
              </div>
            )}

            {/* STEP 2 */}
            {step === 2 && (
              <div>
                <div className="flex border-b border-gray-200 mb-6">
                  <button className={`px-4 py-2 font-medium text-sm ${lineItemTab==='products'?'border-b-2 border-accent text-accent':'text-muted'}`} onClick={() => setLineItemTab('products')}>Products</button>
                  <button className={`px-4 py-2 font-medium text-sm ${lineItemTab==='services'?'border-b-2 border-accent text-accent':'text-muted'}`} onClick={() => setLineItemTab('services')}>Services</button>
                </div>

                {lineItemTab === 'products' && (
                  <div className="space-y-4">
                    {products.map((p, idx) => (
                      <div key={idx} className="flex gap-3 items-end bg-gray-50 p-4 rounded-md relative border border-gray-100">
                        <div className="flex-1 relative">
                          <label className="label text-xs">Product Name *</label>
                          <input 
                            className="input w-full" 
                            value={p.name} 
                            onChange={e => {
                              const newP = [...products]; newP[idx].name = e.target.value; setProducts(newP);
                              setActiveInput({ type: 'product', index: idx });
                            }} 
                          />
                          {activeInput?.type === 'product' && activeInput.index === idx && suggestions.length > 0 && (
                            <div className="absolute top-full left-0 right-0 bg-white border border-gray-200 shadow-lg rounded mt-1 z-10 max-h-48 overflow-y-auto">
                              {suggestions.map((s, i) => (
                                <div key={i} className="p-2 hover:bg-gray-50 cursor-pointer text-sm" onClick={() => handleSuggestionSelect(s)}>
                                  <div className="font-medium text-ink">{s.hsnOrSacCode} - {s.gstRate}% GST</div>
                                  <div className="text-xs text-muted truncate">{s.description}</div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                        <div className="w-24">
                          <label className="label text-xs">HSN/SAC Code</label>
                          <input className="input w-full" value={p.hsnCode} onChange={e => {const newP = [...products]; newP[idx].hsnCode = e.target.value; setProducts(newP);}} />
                        </div>
                        <div className="w-24">
                          <label className="label text-xs">Price</label>
                          <input className="input w-full" type="number" value={p.price} onChange={e => {const newP = [...products]; newP[idx].price = parseFloat(e.target.value)||0; setProducts(newP);}} />
                        </div>
                        <div className="w-16">
                          <label className="label text-xs">Qty</label>
                          <input className="input w-full" type="number" value={p.qty} onChange={e => {const newP = [...products]; newP[idx].qty = parseInt(e.target.value)||1; setProducts(newP);}} />
                        </div>
                        <div className="w-24">
                          <label className="label text-xs">GST %</label>
                          <select className="input w-full" value={p.gst} onChange={e => {const newP = [...products]; newP[idx].gst = e.target.value; setProducts(newP);}}>
                            <option value="5">5%</option><option value="12">12%</option><option value="18">18%</option><option value="Others">Others</option>
                          </select>
                        </div>
                        <div className="w-24 text-right pb-2 font-medium text-sm">
                          ${((p.price * p.qty) * (1 + (parseFloat(p.gst==='Others'?p.customGst:p.gst)||0)/100)).toFixed(2)}
                        </div>
                        <button className="p-2 text-red-500 hover:bg-red-50 rounded" onClick={() => setProducts(products.filter((_, i) => i !== idx))}><Trash2 size={16}/></button>
                      </div>
                    ))}
                    <button className="text-sm font-medium text-accent flex items-center gap-1" onClick={() => setProducts([...products, { name: '', hsnCode: '', price: 0, qty: 1, gst: customer.taxPercentage, customGst: '' }])}>
                      <Plus size={14} /> Add Product Line
                    </button>
                  </div>
                )}

                {lineItemTab === 'services' && (
                  <div className="space-y-4">
                    {services.map((s, idx) => (
                      <div key={idx} className="flex gap-3 items-end bg-gray-50 p-4 rounded-md relative border border-gray-100">
                        <div className="flex-1 relative">
                          <label className="label text-xs">Service Name *</label>
                          <input 
                            className="input w-full" 
                            value={s.name} 
                            onChange={e => {
                              const newS = [...services]; newS[idx].name = e.target.value; setServices(newS);
                              setActiveInput({ type: 'service', index: idx });
                            }} 
                          />
                          {activeInput?.type === 'service' && activeInput.index === idx && suggestions.length > 0 && (
                            <div className="absolute top-full left-0 right-0 bg-white border border-gray-200 shadow-lg rounded mt-1 z-10 max-h-48 overflow-y-auto">
                              {suggestions.map((sg, i) => (
                                <div key={i} className="p-2 hover:bg-gray-50 cursor-pointer text-sm" onClick={() => handleSuggestionSelect(sg)}>
                                  <div className="font-medium text-ink">{sg.hsnOrSacCode} - {sg.gstRate}% GST</div>
                                  <div className="text-xs text-muted truncate">{sg.description}</div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                        <div className="w-24">
                          <label className="label text-xs">HSN/SAC Code</label>
                          <input className="input w-full" value={s.sacCode} onChange={e => {const newS = [...services]; newS[idx].sacCode = e.target.value; setServices(newS);}} />
                        </div>
                        <div className="w-24">
                          <label className="label text-xs">Price</label>
                          <input className="input w-full" type="number" value={s.price} onChange={e => {const newS = [...services]; newS[idx].price = parseFloat(e.target.value)||0; setServices(newS);}} />
                        </div>
                        <div className="w-16">
                          <label className="label text-xs">Qty</label>
                          <input className="input w-full" type="number" value={s.qty} onChange={e => {const newS = [...services]; newS[idx].qty = parseInt(e.target.value)||1; setServices(newS);}} />
                        </div>
                        <div className="w-24">
                          <label className="label text-xs">GST %</label>
                          <select className="input w-full" value={s.gst} onChange={e => {const newS = [...services]; newS[idx].gst = e.target.value; setServices(newS);}}>
                            <option value="5">5%</option><option value="12">12%</option><option value="18">18%</option><option value="Others">Others</option>
                          </select>
                        </div>
                        <div className="w-24 text-right pb-2 font-medium text-sm">
                          ${((s.price * s.qty) * (1 + (parseFloat(s.gst==='Others'?s.customGst:s.gst)||0)/100)).toFixed(2)}
                        </div>
                        <button className="p-2 text-red-500 hover:bg-red-50 rounded" onClick={() => setServices(services.filter((_, i) => i !== idx))}><Trash2 size={16}/></button>
                      </div>
                    ))}
                    <button className="text-sm font-medium text-accent flex items-center gap-1" onClick={() => setServices([...services, { name: '', sacCode: '', price: 0, qty: 1, gst: customer.taxPercentage, customGst: '' }])}>
                      <Plus size={14} /> Add Service Line
                    </button>
                  </div>
                )}

                <div className="mt-8 border-t border-gray-200 pt-4 flex justify-end">
                  <div className="w-64 space-y-2">
                    <div className="flex justify-between text-sm text-muted"><span>Subtotal:</span> <span>${totals.sub.toFixed(2)}</span></div>
                    <div className="flex justify-between text-sm text-muted"><span>Est. Tax:</span> <span>${totals.tax.toFixed(2)}</span></div>
                    <div className="flex justify-between font-semibold text-ink text-lg border-t border-gray-100 pt-2"><span>Total:</span> <span>${totals.grand.toFixed(2)}</span></div>
                  </div>
                </div>
              </div>
            )}

            {/* STEP 3 */}
            {step === 3 && (
              <div className="space-y-6">
                <div className="flex justify-between items-start border-b border-gray-200 pb-4">
                  <div>
                    <h2 className="text-2xl font-bold text-ink">INVOICE PREVIEW</h2>
                    <p className="text-sm text-muted mt-1">To: {customer.companyName || customer.name || 'N/A'}</p>
                    <p className="text-sm text-muted">GSTIN: {customer.gstNumber || 'N/A'}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium text-muted">Invoice Number</p>
                    <p className="font-mono bg-gray-100 px-2 py-1 rounded text-ink inline-block mt-1">INV-[TENANT]-YYYY-XXXX</p>
                  </div>
                </div>

                <div>
                  <label className="label">Due Date *</label>
                  <input type="date" className="input w-48" value={dueDate} onChange={e => setDueDate(e.target.value)} />
                </div>

                <div className="bg-gray-50 border border-gray-200 rounded p-4">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-gray-200 text-left text-muted">
                        <th className="pb-2 font-medium">Description</th>
                        <th className="pb-2 font-medium">HSN/SAC</th>
                        <th className="pb-2 font-medium text-right">Qty</th>
                        <th className="pb-2 font-medium text-right">Price</th>
                        <th className="pb-2 font-medium text-right">Tax</th>
                        <th className="pb-2 font-medium text-right">Amount</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-100">
                      {[...products, ...services].filter(i => i.name).map((item, idx) => (
                        <tr key={idx}>
                          <td className="py-2 text-ink">{item.name}</td>
                          <td className="py-2 text-muted">{item.hsnCode || item.sacCode || '-'}</td>
                          <td className="py-2 text-right">{item.qty}</td>
                          <td className="py-2 text-right">${item.price.toFixed(2)}</td>
                          <td className="py-2 text-right">{item.gst}%</td>
                          <td className="py-2 text-right font-medium">${((item.price * item.qty) * (1 + (parseFloat(item.gst==='Others'?item.customGst:item.gst)||0)/100)).toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  <div className="mt-4 pt-4 border-t border-gray-200 flex justify-end">
                    <div className="w-48 text-right">
                      <div className="text-sm text-muted mb-1">Subtotal: ${totals.sub.toFixed(2)}</div>
                      <div className="text-sm text-muted mb-2">GST Total: ${totals.tax.toFixed(2)}</div>
                      <div className="text-lg font-bold text-ink">Total: ${totals.grand.toFixed(2)}</div>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-50 border border-blue-200 rounded p-4 flex gap-4 mt-6">
                  <div className="flex-1">
                    <h3 className="font-medium text-blue-900 text-sm">Automated Notifications</h3>
                    <p className="text-sm text-blue-800 mt-1">
                      Upon generation, an invoice will automatically be sent via:
                    </p>
                    <ul className="text-sm text-blue-800 mt-2 space-y-1 list-disc pl-5">
                      <li><strong>Email:</strong> {customer.email || '(No email provided)'}</li>
                      <li><strong>WhatsApp:</strong> {customer.phone || '(No phone provided)'}</li>
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {/* Actions */}
            <div className="mt-8 flex justify-between items-center pt-6 border-t border-gray-100">
              <button 
                className="btn-secondary" 
                onClick={() => setStep(step - 1)} 
                disabled={step === 1 || loading}
              >
                Back
              </button>
              
              {step < 3 ? (
                <button className="btn-primary" onClick={handleNextStep}>
                  Continue
                </button>
              ) : (
                <button className="btn-primary" onClick={handleGenerate} disabled={!dueDate || loading}>
                  {loading ? 'Generating...' : 'Generate Invoice'}
                </button>
              )}
            </div>
            
          </div>
        </div>
      </div>
    </div>
  );
}
