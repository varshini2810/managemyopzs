import React, { useState, useEffect } from 'react';
import { Download, Search, FileText } from 'lucide-react';
import api from '../../services/api';
import DataTable from '../../components/common/DataTable';
import StatusBadge from '../../components/common/StatusBadge';
import toast from 'react-hot-toast';
import useDebounce from '../../hooks/useDebounce';

export default function ClassicReports() {
  const [activeReport, setActiveReport] = useState('invoices'); // invoices, customers, subscriptions
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [totalElements, setTotalElements] = useState(0);
  const [page, setPage] = useState(0);
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search, 300);

  const reports = [
    { id: 'invoices', label: 'Invoice History' },
    { id: 'customers', label: 'Customer Directory' },
    { id: 'subscriptions', label: 'Subscription Lifecycle' }
  ];

  useEffect(() => {
    fetchReportData();
  }, [activeReport, page, debouncedSearch]);

  const fetchReportData = () => {
    setLoading(true);
    let endpoint = '';
    if (activeReport === 'invoices') endpoint = '/invoices';
    if (activeReport === 'customers') endpoint = '/customers';
    if (activeReport === 'subscriptions') endpoint = '/subscriptions';

    api.get(`${endpoint}?page=${page}&size=20&search=${debouncedSearch}`)
      .then(res => {
        setData(res.data.data?.content || []);
        setTotalElements(res.data.data?.totalElements || 0);
      })
      .catch(() => toast.error('Failed to fetch report data'))
      .finally(() => setLoading(false));
  };

  const handleExport = () => {
    if (!data.length) {
      toast.error('No data to export');
      return;
    }
    
    // Simple CSV export generator
    const header = Object.keys(data[0]).filter(k => typeof data[0][k] !== 'object');
    const csvRows = [];
    csvRows.push(header.join(','));
    
    for (const row of data) {
      const values = header.map(k => {
        const escaped = ('' + row[k]).replace(/"/g, '\\"');
        return `"${escaped}"`;
      });
      csvRows.push(values.join(','));
    }

    const csvData = csvRows.join('\n');
    const blob = new Blob([csvData], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.setAttribute('hidden', '');
    a.setAttribute('href', url);
    a.setAttribute('download', `${activeReport}_export.csv`);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const getColumns = () => {
    if (activeReport === 'invoices') {
      return [
        { header: 'Invoice ID', cell: (row) => <span className="font-mono text-xs">{row.id}</span> },
        { header: 'Customer', cell: (row) => row.customerId },
        { header: 'Total', cell: (row) => `$${row.total}` },
        { header: 'Status', cell: (row) => <StatusBadge status={row.status} /> },
        { header: 'Date', cell: (row) => new Date(row.createdAt).toLocaleDateString() }
      ];
    }
    if (activeReport === 'customers') {
      return [
        { header: 'ID', cell: (row) => <span className="font-mono text-xs">{row.id}</span> },
        { header: 'Name', cell: (row) => <span className="font-medium">{row.firstName} {row.lastName}</span> },
        { header: 'Email', cell: (row) => row.email },
        { header: 'Company', cell: (row) => row.company || '-' },
        { header: 'Created', cell: (row) => new Date(row.createdAt).toLocaleDateString() }
      ];
    }
    if (activeReport === 'subscriptions') {
      return [
        { header: 'Sub ID', cell: (row) => <span className="font-mono text-xs">{row.id}</span> },
        { header: 'Customer ID', cell: (row) => row.customerId },
        { header: 'Plan ID', cell: (row) => row.planId },
        { header: 'Status', cell: (row) => <StatusBadge status={row.status} /> },
        { header: 'Next Billing', cell: (row) => row.nextBillingAt ? new Date(row.nextBillingAt).toLocaleDateString() : '-' }
      ];
    }
    return [];
  };

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6 animate-fade-in">
      <div className="page-header">
        <div>
          <h1 className="page-title">Classic Reports</h1>
          <p className="page-subtitle">Exportable tabular data for accounting and auditing.</p>
        </div>
        <div className="flex items-center gap-3">
          <button className="btn-secondary" onClick={handleExport}>
            <Download size={14} /> Export CSV
          </button>
        </div>
      </div>

      <div className="flex gap-6">
        <div className="w-64 shrink-0">
          <div className="card p-2 space-y-1">
            <div className="px-3 py-2 text-xs font-semibold text-muted uppercase tracking-wider">Reports</div>
            {reports.map(r => (
              <button
                key={r.id}
                onClick={() => { setActiveReport(r.id); setPage(0); }}
                className={`w-full text-left px-3 py-2 rounded text-sm font-medium transition-colors ${
                  activeReport === r.id ? 'bg-accent/10 text-accent' : 'text-slate-600 hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-2">
                  <FileText size={16} />
                  {r.label}
                </div>
              </button>
            ))}
          </div>
        </div>

        <div className="flex-1 card p-0">
          <div className="p-4 border-b border-gray-200 flex items-center justify-between">
            <h3 className="font-semibold text-ink">{reports.find(r => r.id === activeReport)?.label}</h3>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-muted" size={14} />
              <input 
                type="text" 
                className="input pl-9 h-8 text-sm w-64" 
                placeholder="Search report data..." 
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>
          <DataTable 
            columns={getColumns()}
            data={data}
            loading={loading}
            totalElements={totalElements}
            page={page}
            size={20}
            onPageChange={setPage}
          />
        </div>
      </div>
    </div>
  );
}
